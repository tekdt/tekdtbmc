To make the Ventoy version number text 'invisible' edit the colour setting in \grub\grub.cfg to

set VTLE_CLR=#001631
